-- MySQL Administrator dump 1.4
--
-- ------------------------------------------------------
-- Server version	5.5.60-log


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


--
-- Create schema term_project_db
--

CREATE DATABASE IF NOT EXISTS term_project_db;
USE term_project_db;

--
-- Definition of table `admin`
--

DROP TABLE IF EXISTS `admin`;
CREATE TABLE `admin` (
  `admin_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `admin_name` varchar(45) NOT NULL DEFAULT '',
  PRIMARY KEY (`admin_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
INSERT INTO `admin` (`admin_id`,`admin_name`) VALUES 
 (1,'adnan'),
 (2,'admin'),
 (3,'iict-buet'),
 (4,'bd-food');
/*!40000 ALTER TABLE `admin` ENABLE KEYS */;


--
-- Definition of table `customer`
--

DROP TABLE IF EXISTS `customer`;
CREATE TABLE `customer` (
  `customer_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `login_id` int(10) unsigned NOT NULL DEFAULT '0',
  `customer_name` varchar(45) NOT NULL DEFAULT '',
  `pass` varchar(45) NOT NULL DEFAULT '',
  `customer_address` varchar(45) NOT NULL DEFAULT '',
  `customer_email` varchar(45) NOT NULL DEFAULT '',
  `customer_phone` varchar(45) NOT NULL DEFAULT '',
  PRIMARY KEY (`customer_id`),
  KEY `fk1` (`login_id`),
  CONSTRAINT `fk1` FOREIGN KEY (`login_id`) REFERENCES `login` (`login_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

/*!40000 ALTER TABLE `customer` DISABLE KEYS */;
INSERT INTO `customer` (`customer_id`,`login_id`,`customer_name`,`pass`,`customer_address`,`customer_email`,`customer_phone`) VALUES 
 (1,1,'dedarul','iict@@','dhaka','dedarul@gmail.com','01735078327'),
 (2,2,'fahim','iict1','rangpur','fahim@gmail.com','01858637998');
/*!40000 ALTER TABLE `customer` ENABLE KEYS */;


--
-- Definition of table `delivery`
--

DROP TABLE IF EXISTS `delivery`;
CREATE TABLE `delivery` (
  `delivery_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `employee_id` int(10) unsigned NOT NULL DEFAULT '0',
  `delivary_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `delivary_status` varchar(45) NOT NULL DEFAULT '',
  `due_payment` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`delivery_id`),
  KEY `FK_delivery_1` (`employee_id`),
  CONSTRAINT `FK_delivery_1` FOREIGN KEY (`employee_id`) REFERENCES `employee` (`employee_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `delivery`
--

/*!40000 ALTER TABLE `delivery` DISABLE KEYS */;
/*!40000 ALTER TABLE `delivery` ENABLE KEYS */;


--
-- Definition of table `employee`
--

DROP TABLE IF EXISTS `employee`;
CREATE TABLE `employee` (
  `employee_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `admin_id` int(10) unsigned NOT NULL DEFAULT '0',
  `role_id` int(10) unsigned NOT NULL DEFAULT '0',
  `employee_name` varchar(45) NOT NULL DEFAULT '',
  `employee_phone` varchar(45) NOT NULL DEFAULT '',
  `employee_email` varchar(45) NOT NULL DEFAULT '',
  PRIMARY KEY (`employee_id`),
  KEY `FK_employee_1` (`admin_id`),
  KEY `FK_employee_2` (`role_id`),
  CONSTRAINT `FK_employee_1` FOREIGN KEY (`admin_id`) REFERENCES `admin` (`admin_id`),
  CONSTRAINT `FK_employee_2` FOREIGN KEY (`role_id`) REFERENCES `role` (`role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employee`
--

/*!40000 ALTER TABLE `employee` DISABLE KEYS */;
INSERT INTO `employee` (`employee_id`,`admin_id`,`role_id`,`employee_name`,`employee_phone`,`employee_email`) VALUES 
 (1,1,1,'rafiqul','01537656324','emp1@gmail.com'),
 (2,1,1,'arif','01537656888','emp2@gmail.com'),
 (3,2,3,'zubayer','01777656324','emp3@gmail.com'),
 (4,3,2,'zunayed','01936563241','emp4@gmail.com');
/*!40000 ALTER TABLE `employee` ENABLE KEYS */;


--
-- Definition of table `item`
--

DROP TABLE IF EXISTS `item`;
CREATE TABLE `item` (
  `item_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `manager_id` int(10) unsigned NOT NULL DEFAULT '0',
  `item_name` varchar(45) NOT NULL DEFAULT '',
  `item_quantity` int(10) unsigned NOT NULL DEFAULT '0',
  `item_purchase_price` int(10) unsigned NOT NULL DEFAULT '0',
  `item_selling_price` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`item_id`),
  KEY `FK_item_1` (`manager_id`),
  CONSTRAINT `FK_item_1` FOREIGN KEY (`manager_id`) REFERENCES `manager` (`manager_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `item`
--

/*!40000 ALTER TABLE `item` DISABLE KEYS */;
/*!40000 ALTER TABLE `item` ENABLE KEYS */;


--
-- Definition of table `login`
--

DROP TABLE IF EXISTS `login`;
CREATE TABLE `login` (
  `login_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `customer_name` varchar(45) NOT NULL DEFAULT '',
  `pass` varchar(45) NOT NULL DEFAULT '',
  PRIMARY KEY (`login_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

/*!40000 ALTER TABLE `login` DISABLE KEYS */;
INSERT INTO `login` (`login_id`,`customer_name`,`pass`) VALUES 
 (1,'dedarul','iict@@'),
 (2,'fahim','iict1');
/*!40000 ALTER TABLE `login` ENABLE KEYS */;


--
-- Definition of table `manager`
--

DROP TABLE IF EXISTS `manager`;
CREATE TABLE `manager` (
  `manager_id` int(10) unsigned NOT NULL DEFAULT '0',
  `location_id` int(10) unsigned NOT NULL DEFAULT '0',
  `employee_id` int(10) unsigned NOT NULL DEFAULT '0',
  `address` varchar(45) NOT NULL DEFAULT '',
  `manager_name` varchar(45) NOT NULL DEFAULT '',
  `discount` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`manager_id`),
  KEY `FK_manager_1` (`location_id`) USING BTREE,
  KEY `FK_manager_2` (`employee_id`),
  CONSTRAINT `FK_manager_2` FOREIGN KEY (`employee_id`) REFERENCES `employee` (`employee_id`),
  CONSTRAINT `FK_manager_1` FOREIGN KEY (`location_id`) REFERENCES `storage_location` (`location_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `manager`
--

/*!40000 ALTER TABLE `manager` DISABLE KEYS */;
/*!40000 ALTER TABLE `manager` ENABLE KEYS */;


--
-- Definition of table `order`
--

DROP TABLE IF EXISTS `order`;
CREATE TABLE `order` (
  `order_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` int(10) unsigned NOT NULL DEFAULT '0',
  `payment_id` int(10) unsigned NOT NULL DEFAULT '0',
  `item_id` int(10) unsigned NOT NULL DEFAULT '0',
  `order_date` date NOT NULL DEFAULT '0000-00-00',
  `item_quentity` int(10) unsigned NOT NULL DEFAULT '0',
  `total_price` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`order_id`),
  KEY `FK_order_1` (`customer_id`),
  CONSTRAINT `FK_order_1` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`customer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `order`
--

/*!40000 ALTER TABLE `order` DISABLE KEYS */;
/*!40000 ALTER TABLE `order` ENABLE KEYS */;


--
-- Definition of table `order_details`
--

DROP TABLE IF EXISTS `order_details`;
CREATE TABLE `order_details` (
  `order_details_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` int(10) unsigned NOT NULL DEFAULT '0',
  `delivery_id` int(10) unsigned NOT NULL DEFAULT '0',
  `order_status` varchar(45) NOT NULL DEFAULT '',
  PRIMARY KEY (`order_details_id`),
  KEY `FK_order_details_1` (`order_id`),
  CONSTRAINT `FK_order_details_1` FOREIGN KEY (`order_id`) REFERENCES `order` (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `order_details`
--

/*!40000 ALTER TABLE `order_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `order_details` ENABLE KEYS */;


--
-- Definition of table `payment_method`
--

DROP TABLE IF EXISTS `payment_method`;
CREATE TABLE `payment_method` (
  `payment_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` int(10) unsigned NOT NULL DEFAULT '0',
  `payment_type` varchar(45) NOT NULL DEFAULT '',
  `payment_status` varchar(45) NOT NULL DEFAULT '',
  PRIMARY KEY (`payment_id`),
  KEY `FK_payment_method_1` (`customer_id`),
  CONSTRAINT `FK_payment_method_1` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`customer_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payment_method`
--

/*!40000 ALTER TABLE `payment_method` DISABLE KEYS */;
INSERT INTO `payment_method` (`payment_id`,`customer_id`,`payment_type`,`payment_status`) VALUES 
 (1,1,'mobile','paid'),
 (2,2,'visa card','paid');
/*!40000 ALTER TABLE `payment_method` ENABLE KEYS */;


--
-- Definition of table `role`
--

DROP TABLE IF EXISTS `role`;
CREATE TABLE `role` (
  `role_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `admin_id` int(10) unsigned NOT NULL DEFAULT '0',
  `role_name` varchar(45) NOT NULL DEFAULT '',
  PRIMARY KEY (`role_id`),
  KEY `FK_role_1` (`admin_id`),
  CONSTRAINT `FK_role_1` FOREIGN KEY (`admin_id`) REFERENCES `admin` (`admin_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `role`
--

/*!40000 ALTER TABLE `role` DISABLE KEYS */;
INSERT INTO `role` (`role_id`,`admin_id`,`role_name`) VALUES 
 (1,2,'role_1'),
 (2,1,'role_2'),
 (3,3,'role_3'),
 (4,4,'role_4');
/*!40000 ALTER TABLE `role` ENABLE KEYS */;


--
-- Definition of table `storage_location`
--

DROP TABLE IF EXISTS `storage_location`;
CREATE TABLE `storage_location` (
  `location_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `admin_id` int(10) unsigned NOT NULL DEFAULT '0',
  `location_name` varchar(45) NOT NULL DEFAULT '',
  `manager_id` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`location_id`),
  KEY `FK_storage_location_1` (`admin_id`),
  CONSTRAINT `FK_storage_location_1` FOREIGN KEY (`admin_id`) REFERENCES `admin` (`admin_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `storage_location`
--

/*!40000 ALTER TABLE `storage_location` DISABLE KEYS */;
INSERT INTO `storage_location` (`location_id`,`admin_id`,`location_name`,`manager_id`) VALUES 
 (1,1,'dhanmondi',22),
 (2,1,'mohakhali',11),
 (3,1,'gulshan',33),
 (4,1,'azimpur',44),
 (5,1,'gazipur',55),
 (6,1,'uttora',66),
 (7,2,'rajshahi',777),
 (8,2,'shylhet',888),
 (9,3,'khulna',99),
 (10,3,'chittagong',109),
 (11,4,'rangpur',111),
 (12,3,'barishal',199);
/*!40000 ALTER TABLE `storage_location` ENABLE KEYS */;




/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
